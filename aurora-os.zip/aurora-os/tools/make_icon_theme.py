#!/usr/bin/env python3
"""Generates the 'Aurora' icon theme: every app icon is the same rounded square (same size, corner,
gloss and edge), with a simple white symbol. Folders use one blue folder with a small emblem.
Output: stage-aurora/02-overlay/files/usr/share/icons/Aurora/   (pure SVG, no tools needed)"""
import math
import os
import shutil

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "stage-aurora", "02-overlay",
                    "files", "usr", "share", "icons", "Aurora")
S = 'fill="none" stroke="#fff" stroke-width="28" stroke-linecap="round" stroke-linejoin="round"'
F = 'fill="#fff"'


def tile(top, bottom, inner):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<defs>
<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{top}"/><stop offset="1" stop-color="{bottom}"/></linearGradient>
<linearGradient id="h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0.30"/><stop offset="0.55" stop-color="#fff" stop-opacity="0"/></linearGradient>
</defs>
<rect x="16" y="16" width="480" height="480" rx="116" fill="url(#g)"/>
<rect x="16" y="16" width="480" height="480" rx="116" fill="url(#h)"/>
<rect x="17.5" y="17.5" width="477" height="477" rx="114.5" fill="none" stroke="#fff" stroke-opacity="0.22" stroke-width="3"/>
{inner}
</svg>
'''


def gear():
    cx = cy = 256
    pts = []
    for i in range(8):
        a = math.radians(i * 45)
        for da, r in ((-14, 96), (-9, 124), (9, 124), (14, 96)):
            t = a + math.radians(da)
            pts.append((cx + r * math.cos(t), cy + r * math.sin(t)))
    d = "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts) + " Z"
    d += f" M{cx + 44} {cy} a44 44 0 1 0 -88 0 a44 44 0 1 0 88 0 Z"
    return f'<path d="{d}" fill="#fff" fill-rule="evenodd"/>'


GLYPHS = {
    "folder": f'<path d="M132 182 h96 l36 40 h116 a22 22 0 0 1 22 22 v112 a22 22 0 0 1 -22 22 H132 a22 22 0 0 1 -22 -22 V204 a22 22 0 0 1 22 -22 z" {F}/>',
    "gear": gear(),
    "music": (f'<ellipse cx="200" cy="354" rx="40" ry="32" {F}/><ellipse cx="332" cy="326" rx="40" ry="32" {F}/>'
              f'<path d="M238 350 V176 M370 322 V148" {S}/><path d="M238 176 L370 148 V196 L238 224 Z" {F}/>'),
    "notes": (f'<rect x="136" y="116" width="176" height="262" rx="30" {S}/><path d="M176 190 h96 M176 240 h96 M176 290 h56" {S}/>'
              f'<path d="M356 196 l44 44 l-118 118 l-60 16 l16 -60 z" {F}/>'),
    "store": f'<path d="M256 136 V300 M194 240 L256 302 L318 240" {S}/><path d="M146 330 v28 a24 24 0 0 0 24 24 h172 a24 24 0 0 0 24 -24 v-28" {S}/>',
    "terminal": f'<path d="M156 188 L238 256 L156 324" {S}/><path d="M276 336 H366" {S}/>',
    "calculator": (f'<rect x="140" y="104" width="232" height="304" rx="38" {S}/><rect x="176" y="146" width="160" height="56" rx="16" {F}/>'
                   + "".join(f'<circle cx="{x}" cy="{y}" r="17" {F}/>' for y in (254, 308, 362) for x in (196, 256, 316))),
    "monitor": f'<path d="M104 272 H184 L222 186 L276 340 L318 250 H408" {S}/>',
    "gallery": (f'<rect x="124" y="136" width="264" height="240" rx="38" {S}/><circle cx="324" cy="204" r="22" {F}/>'
                f'<path d="M124 330 L206 252 L256 302 L302 260 L388 344" {S}/>'),
    "globe": (f'<circle cx="256" cy="256" r="122" {S}/><ellipse cx="256" cy="256" rx="54" ry="122" {S}/>'
              f'<path d="M134 256 H378 M152 192 H360 M152 320 H360" {S}/>'),
    "home": "".join(f'<rect x="{x}" y="{y}" width="102" height="102" rx="28" {F} fill-opacity="{o}"/>'
                    for x, y, o in ((142, 142, 1), (268, 142, 0.78), (142, 268, 0.78), (268, 268, 1))),
    "grid": "".join(f'<circle cx="{x}" cy="{y}" r="23" {F}/>' for y in (170, 256, 342) for x in (170, 256, 342)),
    "trash": (f'<path d="M144 184 H368" {S}/><path d="M222 184 V164 a12 12 0 0 1 12 -12 h44 a12 12 0 0 1 12 12 V184" {S}/>'
              f'<path d="M168 184 L182 376 a26 26 0 0 0 26 24 h96 a26 26 0 0 0 26 -24 L344 184" {S}/><path d="M226 232 V348 M286 232 V348" {S}/>'),
    "control": (f'<path d="M136 184 H376 M136 256 H376 M136 328 H376" {S}/>'
                f'<circle cx="204" cy="184" r="26" {F}/><circle cx="308" cy="256" r="26" {F}/><circle cx="232" cy="328" r="26" {F}/>'),
    "archive": (f'<rect x="132" y="150" width="248" height="70" rx="18" {S}/><path d="M152 220 v118 a34 34 0 0 0 34 34 h140 a34 34 0 0 0 34 -34 V220" {S}/>'
                f'<path d="M222 276 h68" {S}/>'),
    "screenshot": (f'<path d="M146 214 V170 a22 22 0 0 1 22 -22 H212 M300 148 H344 a22 22 0 0 1 22 22 V214 M366 300 V344 a22 22 0 0 1 -22 22 H300 M212 366 H168 a22 22 0 0 1 -22 -22 V300" {S}/>'
                   f'<circle cx="256" cy="256" r="36" {F}/>'),
    "disk": (f'<rect x="120" y="196" width="272" height="120" rx="36" {S}/><circle cx="340" cy="256" r="13" {F}/><path d="M160 256 H262" {S}/>'),
    "backup": (f'<path d="M158 256 a100 100 0 1 1 30 70" {S}/><path d="M256 190 V256 L300 284" {S}/>'
               f'<path d="M110 236 L158 262 L196 218 Z" {F}/>'),
    "pie": (f'<circle cx="256" cy="256" r="118" {S}/><path d="M256 256 V138 A118 118 0 0 1 374 256 Z" {F}/>'),
    "calendar": (f'<rect x="132" y="150" width="248" height="232" rx="38" {S}/><path d="M132 224 H380 M196 116 V170 M316 116 V170" {S}/>'
                 + "".join(f'<circle cx="{x}" cy="{y}" r="12" {F}/>' for y in (270, 326) for x in (192, 256, 320))),
}

# icon file -> (glyph, top colour, bottom colour, [icon names it answers to])
APPS = {
    "files":      ("folder", "#5aa9ff", "#2a62e0", ["system-file-manager", "org.kde.dolphin", "dolphin"]),
    "settings":   ("gear", "#a5aebf", "#5b6578", ["preferences-system", "systemsettings", "org.kde.systemsettings", "preferences-desktop"]),
    "music":      ("music", "#ff7a98", "#e0245e", ["aurora-music", "multimedia-audio-player", "org.kde.elisa"]),
    "notes":      ("notes", "#ffcb5a", "#f58a1f", ["org.xfce.mousepad", "accessories-text-editor", "mousepad", "text-editor"]),
    "store":      ("store", "#52d0ff", "#2a6cf0", ["org.kde.discover", "plasmadiscover", "system-software-install", "software-center"]),
    "terminal":   ("terminal", "#4a5268", "#1b2030", ["utilities-terminal", "org.kde.konsole", "konsole"]),
    "calculator": ("calculator", "#7e8499", "#383d50", ["accessories-calculator", "org.kde.kcalc", "kcalc"]),
    "monitor":    ("monitor", "#5fe3a8", "#16a470", ["utilities-system-monitor", "org.kde.plasma-systemmonitor", "plasma-systemmonitor", "org.kde.ksysguard"]),
    "gallery":    ("gallery", "#c58bff", "#6c46e6", ["org.kde.gwenview", "gwenview", "image-viewer"]),
    "firefox":    ("globe", "#ffa04a", "#e0457c", ["firefox-esr", "firefox"]),
    "chrome":     ("globe", "#5db0ff", "#22b585", ["google-chrome", "google-chrome-stable"]),
    "chromium":   ("globe", "#7aa7ff", "#3a5fd9", ["chromium", "chromium-browser", "web-browser"]),
    "home":       ("home", "#8aa0ff", "#5058e0", ["aurora-home"]),
    "grid":       ("grid", "#4b5268", "#1e2232", ["view-app-grid", "applications-all"]),
    "control":    ("control", "#b79cff", "#6a45e0", ["aurora-control"]),
    "archive":    ("archive", "#d9a066", "#9c6532", ["org.kde.ark", "ark", "package-x-generic"]),
    "screenshot": ("screenshot", "#6fd2ff", "#2d86e0", ["org.kde.spectacle", "spectacle", "applets-screenshooter"]),
    "disks":      ("disk", "#8c96ab", "#475066", ["gparted", "org.kde.partitionmanager", "partitionmanager"]),
    "backup":     ("backup", "#58d6c6", "#1c9a96", ["timeshift", "timeshift-gtk"]),
    "filelight":  ("pie", "#ff8f6b", "#e0455a", ["org.kde.filelight", "filelight"]),
    "calendar":   ("calendar", "#ff7a7a", "#e03a52", ["office-calendar", "org.kde.korganizer"]),
}

# folder emblems (drawn small, white, on the front of the folder)
EMBLEM = {
    "": "",
    "documents": '<path d="M200 300 H312 M200 344 H312 M200 388 H268" stroke="#fff" stroke-width="22" stroke-linecap="round"/>',
    "download": '<path d="M256 292 V392 M214 352 L256 394 L298 352" fill="none" stroke="#fff" stroke-width="24" stroke-linecap="round" stroke-linejoin="round"/>',
    "music": '<ellipse cx="226" cy="388" rx="26" ry="21" fill="#fff"/><path d="M250 384 V298 L316 284 V366" fill="none" stroke="#fff" stroke-width="20" stroke-linecap="round" stroke-linejoin="round"/><ellipse cx="292" cy="368" rx="26" ry="21" fill="#fff"/>',
    "pictures": '<path d="M180 392 L232 336 L268 372 L300 338 L336 392 Z" fill="#fff"/><circle cx="308" cy="302" r="16" fill="#fff"/>',
    "videos": '<path d="M226 296 L318 346 L226 396 Z" fill="#fff"/>',
    "desktop": '<rect x="184" y="296" width="144" height="92" rx="14" fill="none" stroke="#fff" stroke-width="22"/><path d="M232 414 H280" stroke="#fff" stroke-width="22" stroke-linecap="round"/>',
    "home": '<path d="M178 350 L256 284 L334 350 M200 342 V400 H312 V342" fill="none" stroke="#fff" stroke-width="22" stroke-linecap="round" stroke-linejoin="round"/>',
}
FOLDERS = {
    "folder": ["folder", "inode-directory", "folder-open", "folder-blue"],
    "documents": ["folder-documents"], "download": ["folder-download"], "music": ["folder-music"],
    "pictures": ["folder-pictures"], "videos": ["folder-videos"], "desktop": ["user-desktop", "folder-desktop"],
    "home": ["user-home", "folder-home"],
}


def folder_svg(emblem):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<defs>
<linearGradient id="b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4f9bf7"/><stop offset="1" stop-color="#2a62d8"/></linearGradient>
<linearGradient id="f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8cc4ff"/><stop offset="1" stop-color="#3f86ee"/></linearGradient>
</defs>
<path d="M56 140 a38 38 0 0 1 38 -38 h98 a30 30 0 0 1 24 12 l22 30 h176 a38 38 0 0 1 38 38 v60 H56 z" fill="url(#b)"/>
<path d="M56 216 a38 38 0 0 1 38 -38 h324 a38 38 0 0 1 38 38 v176 a38 38 0 0 1 -38 38 H94 a38 38 0 0 1 -38 -38 z" fill="url(#f)"/>
<path d="M94 179 h324" stroke="#fff" stroke-opacity="0.45" stroke-width="3" fill="none"/>
{emblem}
</svg>
'''


def trash_svg(full):
    paper = ('<path d="M196 150 L214 110 L262 120 L254 156 Z M262 150 L286 108 L330 126 L310 160 Z" fill="#ffffff" fill-opacity="0.85"/>'
             if full else "")
    return tile("#a2abbd", "#566074", paper + GLYPHS["trash"])


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def main():
    shutil.rmtree(ROOT, ignore_errors=True)
    count = 0
    for key, (glyph, top, bottom, names) in APPS.items():
        svg = tile(top, bottom, GLYPHS[glyph])
        for n in names:
            write(os.path.join(ROOT, "scalable", "apps", n + ".svg"), svg)
            count += 1
    for emblem, names in FOLDERS.items():
        svg = folder_svg(EMBLEM["" if emblem == "folder" else emblem])
        for n in names:
            for d in ("places", "mimetypes"):
                write(os.path.join(ROOT, "scalable", d, n + ".svg"), svg)
            count += 1
    for name, full in (("user-trash", False), ("user-trash-full", True)):
        write(os.path.join(ROOT, "scalable", "places", name + ".svg"), trash_svg(full))
        write(os.path.join(ROOT, "scalable", "apps", name + ".svg"), trash_svg(full))
        count += 1
    dirs = "scalable/apps,scalable/places,scalable/mimetypes"
    idx = ["[Icon Theme]", "Name=Aurora", "Comment=Aurora icons: one shape, one style",
           "Inherits=Papirus-Dark,breeze-dark,hicolor", f"Directories={dirs}", ""]
    for d, ctx in (("scalable/apps", "Applications"), ("scalable/places", "Places"), ("scalable/mimetypes", "MimeTypes")):
        idx += [f"[{d}]", "Size=128", "MinSize=16", "MaxSize=512", "Type=Scalable", f"Context={ctx}", ""]
    write(os.path.join(ROOT, "index.theme"), "\n".join(idx))
    print(f"{count} icon files written to {ROOT}")


if __name__ == "__main__":
    main()
