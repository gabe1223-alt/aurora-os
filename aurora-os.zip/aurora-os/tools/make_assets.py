#!/usr/bin/env python3
"""Regenerates the wallpapers and logo. Needs: pip install pillow numpy"""
import math
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                    "stage-aurora", "02-overlay", "files", "usr")
W, H = 1920, 1080


def gradient(top, bottom):
    t = np.linspace(0, 1, H)[:, None, None]
    a, b = np.array(top, float), np.array(bottom, float)
    return np.broadcast_to(a + (b - a) * t, (H, W, 3)).copy()


def ribbon(canvas, color, y0, amp, freq, phase, thick, alpha):
    layer = np.zeros((H, W), float)
    xs = np.arange(W)
    for x in xs[::1]:
        c = y0 + amp * math.sin(x * freq + phase) + 0.4 * amp * math.sin(x * freq * 2.3 + phase * 1.7)
        ys = np.arange(H)
        layer[:, x] = np.exp(-((ys - c) / thick) ** 2)
    img = Image.fromarray((layer * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(28))
    m = np.asarray(img, float)[:, :, None] / 255.0 * alpha
    canvas += m * (np.array(color, float) - canvas) * 1.0
    return canvas


def stars(canvas, n, seed):
    rng = np.random.default_rng(seed)
    for _ in range(n):
        x, y = int(rng.integers(0, W)), int(rng.integers(0, H * 0.7))
        canvas[y:y + 2, x:x + 2] = np.clip(canvas[y:y + 2, x:x + 2] + rng.uniform(60, 160), 0, 255)
    return canvas


def save(name, canvas):
    d = os.path.join(ROOT, "share", "wallpapers", name, "contents", "images")
    os.makedirs(d, exist_ok=True)
    Image.fromarray(np.clip(canvas, 0, 255).astype(np.uint8)).save(
        os.path.join(d, "1920x1080.jpg"), quality=88, optimize=True)


# Dawn: teal -> violet -> warm horizon
c = gradient((8, 14, 40), (70, 30, 90))
c = ribbon(c, (60, 230, 190), 420, 90, 0.0031, 0.4, 70, 0.80)
c = ribbon(c, (120, 140, 255), 520, 70, 0.0042, 2.1, 55, 0.65)
c = ribbon(c, (255, 130, 190), 640, 60, 0.0027, 4.0, 45, 0.50)
save("AuroraDawn", stars(c, 260, 1))

# Night: deep blue with green curtains
c = gradient((3, 6, 20), (10, 24, 48))
c = ribbon(c, (70, 255, 160), 360, 110, 0.0028, 1.0, 85, 0.85)
c = ribbon(c, (40, 200, 220), 470, 80, 0.0039, 3.3, 60, 0.55)
save("AuroraNight", stars(c, 420, 2))

# Bloom: warm magenta/orange
c = gradient((25, 8, 40), (120, 40, 80))
c = ribbon(c, (255, 170, 90), 560, 80, 0.0030, 0.2, 75, 0.70)
c = ribbon(c, (255, 90, 170), 470, 100, 0.0036, 2.6, 60, 0.65)
c = ribbon(c, (150, 120, 255), 380, 60, 0.0045, 4.4, 45, 0.50)
save("AuroraBloom", stars(c, 180, 3))

# ---- Logo: deep-space tile with three glowing aurora ribbons ----
S = 1024
yy, xx = np.mgrid[0:S, 0:S]
t = ((xx * 0.35 + yy * 0.65) / S)[..., None]
c1, c2 = np.array([14, 22, 48], float), np.array([40, 22, 96], float)
tile = Image.fromarray((c1 * (1 - t) + c2 * t).astype(np.uint8)).convert("RGBA")
rib = Image.new("RGBA", (S, S), (0, 0, 0, 0))
glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
for yc, amp, col, wd, ph in ((330, 90, (70, 235, 190), 52, 0.0),
                             (450, 100, (130, 150, 255), 46, 0.9),
                             (570, 85, (255, 140, 200), 40, 1.8)):
    pts = [(x, yc + amp * math.sin((x / S) * 2 * math.pi * 1.1 + ph)) for x in np.arange(150, S - 149, 0.5)]
    for layer, width, alpha in ((glow, wd * 2.4, 150), (rib, wd, 255)):
        d = ImageDraw.Draw(layer)
        r = width / 2
        for (x, y) in pts:  # stamp round dots along the curve: smooth edges
            d.ellipse((x - r, y - r, x + r, y + r), fill=col + (alpha,))
glow = glow.filter(ImageFilter.GaussianBlur(30))
tile = Image.alpha_composite(Image.alpha_composite(tile, glow), rib)
d = ImageDraw.Draw(tile)
for (x, y, r, a) in ((250, 190, 9, 240), (770, 160, 6, 220), (870, 300, 5, 200),
                     (190, 770, 5, 190), (830, 830, 7, 220), (520, 120, 4, 180)):
    d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 255, 255, a))
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle((24, 24, S - 24, S - 24), radius=230, fill=255)
tile.putalpha(mask)
img = tile.resize((512, 512), Image.LANCZOS)

logo = os.path.join(ROOT, "share", "aurora")
os.makedirs(logo, exist_ok=True)
img.save(os.path.join(logo, "logo.png"))
pl = os.path.join(ROOT, "share", "plymouth", "themes", "aurora")
os.makedirs(pl, exist_ok=True)
img.resize((256, 256), Image.LANCZOS).save(os.path.join(pl, "logo.png"))
for size in (256, 64):
    p = os.path.join(ROOT, "share", "icons", "hicolor", f"{size}x{size}", "apps")
    os.makedirs(p, exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(os.path.join(p, "aurora-logo.png"))

# ---- Plymouth wordmark + progress bar ----
try:
    font = ImageFont.truetype("DejaVuSans.ttf", 34)
except OSError:
    font = ImageFont.load_default(size=34)
word = Image.new("RGBA", (420, 60), (0, 0, 0, 0))
wd_ = ImageDraw.Draw(word)
x = 10
for ch in "AURORA":
    wd_.text((x, 8), ch, font=font, fill=(235, 240, 255, 235))
    x += wd_.textlength(ch, font=font) + 22
word = word.crop((0, 0, int(x), 60))
word.save(os.path.join(pl, "wordmark.png"))
for name, col in (("bar_bg", (255, 255, 255, 45)), ("bar_fg", (130, 150, 255, 255))):
    bar = Image.new("RGBA", (320, 6), (0, 0, 0, 0))
    ImageDraw.Draw(bar).rounded_rectangle((0, 0, 319, 5), radius=3, fill=col)
    bar.save(os.path.join(pl, name + ".png"))
print("assets written")
