#!/usr/bin/env python3
"""Generates the Aurora wallpaper set. Needs: pip install pillow numpy"""
import json, os, shutil
import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "stage-aurora",
                    "02-overlay", "files", "usr", "share", "wallpapers")
W, H = 2560, 1440
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
rng = np.random.default_rng(7)


def vgrad(top, bot):
    t = (yy / H)[..., None]
    return np.array(top, np.float32) * (1 - t) + np.array(bot, np.float32) * t


def make(name, title, sky, layers, glow=None):
    img = vgrad(*sky)
    if glow:  # soft radial light
        cx, cy, rad, col, a = glow
        d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / rad
        m = np.clip(1 - d, 0, 1) ** 2 * a
        img = img * (1 - m[..., None]) + np.array(col, np.float32) * m[..., None]
    x = np.arange(W, dtype=np.float32)
    for (ctop, cbot, y0, a1, f1, p1, a2, f2, p2, alpha) in layers:
        bnd = y0 + a1 * np.sin(x / W * 2 * np.pi * f1 + p1) + a2 * np.sin(x / W * 2 * np.pi * f2 + p2)
        edge = np.clip((yy - bnd[None, :]) / 70.0 + 0.5, 0, 1)
        edge = edge * edge * (3 - 2 * edge)
        span = np.clip((yy - bnd[None, :]) / (H - y0 + 1), 0, 1)[..., None]
        col = np.array(ctop, np.float32) * (1 - span) + np.array(cbot, np.float32) * span
        m = (edge * alpha)[..., None]
        img = img * (1 - m) + col * m
    img += rng.normal(0, 1.3, img.shape).astype(np.float32)  # dither: no colour banding
    out = Image.fromarray(np.clip(img, 0, 255).astype(np.uint8))
    d = os.path.join(ROOT, name, "contents", "images")
    os.makedirs(d, exist_ok=True)
    out.save(os.path.join(d, "2560x1440.jpg"), quality=90, optimize=True)
    with open(os.path.join(ROOT, name, "metadata.json"), "w") as fh:
        json.dump({"KPlugin": {"Authors": [{"Name": "Aurora OS"}], "Id": name, "Name": title,
                               "License": "CC-BY-SA-4.0"}, "KPackageStructure": "Wallpaper/Images"}, fh, indent=2)


for old in ("AuroraDawn", "AuroraNight", "AuroraBloom"):
    shutil.rmtree(os.path.join(ROOT, old), ignore_errors=True)

make("AuroraDaybreak", "Aurora Daybreak", ((255, 226, 214), (196, 214, 255)),
     [((255, 190, 170), (250, 150, 175), 760, 70, 1.3, 0.4, 28, 2.7, 1.0, 0.95),
      ((246, 150, 185), (190, 130, 225), 880, 60, 1.1, 2.2, 24, 3.1, 0.2, 0.95),
      ((170, 135, 235), (110, 120, 220), 1000, 55, 0.9, 4.1, 22, 2.3, 2.4, 0.97),
      ((110, 120, 225), (70, 90, 190), 1130, 45, 1.2, 1.4, 18, 3.4, 3.3, 1.0)],
     glow=(1900, 380, 1100, (255, 245, 225), 0.8))
make("AuroraDusk", "Aurora Dusk", ((52, 36, 104), (244, 140, 120)),
     [((120, 70, 150), (70, 50, 130), 760, 70, 1.3, 0.6, 28, 2.7, 1.4, 0.95),
      ((90, 60, 150), (50, 45, 120), 880, 60, 1.1, 2.4, 24, 3.1, 0.6, 0.96),
      ((60, 50, 135), (34, 36, 98), 1010, 55, 0.9, 4.3, 22, 2.3, 2.8, 0.98),
      ((36, 34, 100), (20, 22, 70), 1140, 45, 1.2, 1.6, 18, 3.4, 3.7, 1.0)],
     glow=(700, 560, 1200, (255, 170, 130), 0.85))
make("AuroraMidnight", "Aurora Midnight", ((8, 12, 34), (22, 30, 70)),
     [((30, 90, 120), (14, 50, 84), 800, 70, 1.2, 0.2, 26, 2.8, 1.1, 0.9),
      ((24, 70, 118), (12, 40, 80), 920, 58, 1.0, 2.0, 22, 3.2, 0.3, 0.94),
      ((18, 50, 100), (10, 28, 62), 1040, 52, 0.9, 3.9, 20, 2.4, 2.5, 0.97),
      ((12, 30, 72), (6, 14, 40), 1160, 44, 1.2, 1.2, 16, 3.5, 3.1, 1.0)],
     glow=(1700, 300, 900, (70, 200, 190), 0.35))
make("AuroraBloom", "Aurora Bloom", ((255, 214, 190), (255, 160, 150)),
     [((255, 150, 140), (240, 100, 150), 780, 66, 1.3, 0.9, 26, 2.9, 0.3, 0.95),
      ((236, 100, 150), (170, 90, 190), 900, 58, 1.1, 2.7, 22, 3.3, 1.7, 0.96),
      ((160, 90, 190), (110, 80, 190), 1020, 52, 0.9, 4.6, 20, 2.5, 3.0, 0.98),
      ((100, 80, 185), (60, 60, 150), 1150, 44, 1.2, 1.9, 16, 3.6, 3.8, 1.0)],
     glow=(1500, 420, 1000, (255, 235, 200), 0.7))
print("wallpapers written")
