#!/bin/bash -e
install -m 644 files/packages.list "${ROOTFS_DIR}/tmp/aurora-packages.list"
