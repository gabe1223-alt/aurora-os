#!/bin/bash -e
export DEBIAN_FRONTEND=noninteractive
LIST=/tmp/aurora-packages.list

available() {
	apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/ {print $2}' | grep -qv '^(none)$'
}

pkgs=()
fail=0
while IFS= read -r line; do
	line="${line%%#*}"
	line="$(echo "$line" | xargs)"
	[ -z "$line" ] && continue
	case "$line" in
	\?*)
		p="${line#\?}"
		if available "$p"; then pkgs+=("$p"); else echo "WARNING: optional package '$p' not available - skipped"; fi
		;;
	*)
		if available "$line"; then pkgs+=("$line"); else echo "ERROR: required package '$line' not available"; fail=1; fi
		;;
	esac
done < "$LIST"

if [ "$fail" = 1 ]; then
	echo "Fix the package names above in stage-aurora/01-packages/files/packages.list"
	exit 1
fi

echo "Installing ${#pkgs[@]} packages..."
apt-get install -y --no-install-recommends "${pkgs[@]}"
rm -f "$LIST"
