// Aurora desktop: slim menu bar on top, floating icon dock at the bottom.
// Executed once per user by /usr/lib/aurora/apply-layout via plasmashell's scripting API.
var wallpaper = "file:///usr/share/wallpapers/AuroraDusk";

var oldPanels = panels();
for (var i = 0; i < oldPanels.length; i++) {
    oldPanels[i].remove();
}

// ---------- top menu bar ----------
var bar = new Panel;
bar.location = "top";
bar.height = 30;
bar.hiding = "none";
bar.opacity = "translucent";

var apple = bar.addWidget("org.kde.plasma.kickoff");
apple.currentConfigGroup = ["General"];
apple.writeConfig("icon", "aurora-logo");

bar.addWidget("org.kde.plasma.appmenu");          // global menu of the active app
bar.addWidget("org.kde.plasma.panelspacer");      // pushes the rest to the right
bar.addWidget("org.kde.plasma.systemtray");

var clock = bar.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", true);
clock.writeConfig("dateDisplayFormat", "BesideTime");
clock.writeConfig("dateFormat", "custom");
clock.writeConfig("customDateFormat", "ddd d MMM");

// ---------- bottom dock ----------
var dock = new Panel;
dock.location = "bottom";
dock.height = 66;
dock.hiding = "none";
dock.floating = true;
dock.opacity = "translucent";
dock.alignment = "center";
dock.lengthMode = "fit";

var grid = dock.addWidget("org.kde.plasma.kickerdash");   // full-screen app grid (Launchpad style)
grid.currentConfigGroup = ["General"];
grid.writeConfig("icon", "view-app-grid");

var tasks = dock.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers",
    "applications:org.kde.dolphin.desktop,applications:firefox-esr.desktop," +
    "applications:google-chrome.desktop,applications:chromium.desktop," +
    "applications:org.kde.discover.desktop,applications:org.kde.konsole.desktop," +
    "applications:systemsettings.desktop");
tasks.writeConfig("maxStripes", 1);
tasks.writeConfig("iconSpacing", 2);

dock.addWidget("org.kde.plasma.marginsseparator");
dock.addWidget("org.kde.plasma.trash");

// ---------- wallpaper ----------
var all = desktops();
for (var j = 0; j < all.length; j++) {
    all[j].wallpaperPlugin = "org.kde.image";
    all[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    all[j].writeConfig("Image", wallpaper);
}
