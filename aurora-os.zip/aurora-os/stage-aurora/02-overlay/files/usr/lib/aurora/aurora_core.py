"""Aurora core: Qt-free logic shared by Aurora Music, Aurora Home and Aurora Control.

Everything here works without a display, so it can be tested on its own.
"""
import json
import os
import re
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date, datetime
from pathlib import Path

HOME = Path.home()
CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", HOME / ".config")) / "aurora"
CACHE = Path(os.environ.get("XDG_CACHE_HOME", HOME / ".cache")) / "aurora"
AUDIO_EXT = {".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wav", ".wma"}
COVER_NAMES = ("cover", "folder", "front", "album", "artwork", "albumart")
COVER_EXT = (".jpg", ".jpeg", ".png", ".webp")


# ---------------------------------------------------------------- json helpers
def read_json(path, default):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


# ---------------------------------------------------------------- theme / settings
DEFAULT_THEME = {"mode": "dark", "accent": "#8296ff", "radius": 18, "adaptive_art": True}


def load_theme():
    t = dict(DEFAULT_THEME)
    t.update(read_json(CONFIG / "theme.json", {}))
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", str(t.get("accent", ""))):
        t["accent"] = DEFAULT_THEME["accent"]
    if t.get("mode") not in ("dark", "light"):
        t["mode"] = "dark"
    return t


def save_theme(theme):
    write_json(CONFIG / "theme.json", theme)


DEFAULT_HOME = {
    "cards": ["clock", "weather", "calendar", "events", "now_playing", "system", "controls", "recent", "note"],
    "city": "", "lat": None, "lon": None, "units": "metric", "clock_24h": True,
    "week_start": 0, "contextual": True,
}


def load_home():
    h = dict(DEFAULT_HOME)
    h.update(read_json(CONFIG / "home.json", {}))
    return h


def save_home(cfg):
    write_json(CONFIG / "home.json", cfg)


# ---------------------------------------------------------------- time of day
def day_part(now=None):
    h = (now or datetime.now()).hour
    if 5 <= h < 12:
        return "morning"
    if 12 <= h < 18:
        return "afternoon"
    if 18 <= h < 23:
        return "evening"
    return "night"


def greeting(name, now=None):
    part = day_part(now)
    word = {"morning": "Good morning", "afternoon": "Good afternoon",
            "evening": "Good evening", "night": "Good night"}[part]
    return f"{word}, {name}" if name else word


def contextual_order(cards, now=None):
    """Move the most useful cards to the front for the time of day."""
    part = day_part(now)
    first = {"morning": ["clock", "weather", "events", "calendar"],
             "afternoon": ["clock", "events", "calendar", "weather"],
             "evening": ["clock", "now_playing", "weather", "controls"],
             "night": ["clock", "now_playing", "controls", "system"]}[part]
    head = [c for c in first if c in cards]
    return head + [c for c in cards if c not in head]


def fmt_time(seconds):
    seconds = int(max(0, seconds))
    return f"{seconds // 60}:{seconds % 60:02d}"


# ---------------------------------------------------------------- music: tags + library
def read_tags(path):
    """Tags and duration for one file. Never raises; falls back to the file name."""
    p = Path(path)
    tags = {"path": str(p), "title": p.stem, "artist": "Unknown Artist",
            "album": "Unknown Album", "track": 0, "duration": 0.0}
    try:
        import mutagen
        f = mutagen.File(str(p), easy=True)
        if f is None:
            return tags
        length = getattr(f.info, "length", 0) or 0
        tags["duration"] = float(length)

        def first(key):
            v = f.get(key)
            return str(v[0]).strip() if v else ""
        tags["title"] = first("title") or tags["title"]
        tags["artist"] = first("artist") or first("albumartist") or tags["artist"]
        tags["album"] = first("album") or tags["album"]
        m = re.match(r"\d+", first("tracknumber"))
        tags["track"] = int(m.group()) if m else 0
    except Exception:
        pass
    return tags


def iter_audio_files(folders):
    seen = set()
    for folder in folders:
        folder = os.path.expanduser(str(folder))
        if os.path.isfile(folder):
            if Path(folder).suffix.lower() in AUDIO_EXT:
                yield folder
            continue
        for root, dirs, files in os.walk(folder):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for name in sorted(files):
                if Path(name).suffix.lower() in AUDIO_EXT:
                    full = os.path.join(root, name)
                    real = os.path.realpath(full)
                    if real not in seen:
                        seen.add(real)
                        yield full


class Library:
    """Track list with an on-disk cache, so the second start is instant."""

    def __init__(self, cache_file=None):
        self.cache_file = Path(cache_file or CACHE / "music-library.json")
        self.cache = read_json(self.cache_file, {})

    def cached_tracks(self):
        return sorted((dict(v, path=k) for k, v in self.cache.items() if os.path.exists(k)), key=sort_key)

    def scan(self, folders, batch=40):
        """Yield lists of track dicts; call save() when finished."""
        found, out = {}, []
        for path in iter_audio_files(folders):
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                continue
            c = self.cache.get(path)
            if c and c.get("mtime") == mtime:
                t = dict(c, path=path)
            else:
                t = read_tags(path)
                t["mtime"] = mtime
            found[path] = {k: v for k, v in t.items() if k != "path"}
            out.append(t)
            if len(out) >= batch:
                yield out
                out = []
        if out:
            yield out
        self.cache = found

    def save(self):
        write_json(self.cache_file, self.cache)


def sort_key(t):
    return (t.get("artist", "").lower(), t.get("album", "").lower(), t.get("track", 0), t.get("title", "").lower())


def read_cover_bytes(path):
    """Embedded artwork if present, else cover.jpg/folder.jpg next to the file."""
    try:
        import mutagen
        f = mutagen.File(str(path))
        tags = getattr(f, "tags", None)
        if tags is not None:
            for key in list(tags.keys()):
                if str(key).startswith("APIC"):
                    return tags[key].data
            covr = tags.get("covr") if hasattr(tags, "get") else None
            if covr:
                return bytes(covr[0])
        pics = getattr(f, "pictures", None)
        if pics:
            return pics[0].data
        if tags is not None and hasattr(tags, "get"):
            blocks = tags.get("metadata_block_picture")
            if blocks:
                import base64
                from mutagen.flac import Picture
                return Picture(base64.b64decode(blocks[0])).data
    except Exception:
        pass
    d = Path(path).parent
    try:
        names = {p.name.lower(): p for p in d.iterdir() if p.is_file()}
    except OSError:
        return None
    for base in COVER_NAMES:
        for ext in COVER_EXT:
            if base + ext in names:
                try:
                    return names[base + ext].read_bytes()
                except OSError:
                    return None
    return None


# playlists ----------------------------------------------------------------
PLAYLISTS_FILE = CONFIG / "playlists.json"


def load_playlists():
    d = read_json(PLAYLISTS_FILE, {})
    d.setdefault("favorites", [])
    d.setdefault("lists", {})
    return d


def save_playlists(d):
    write_json(PLAYLISTS_FILE, d)


# now-playing state (read by Aurora Home) --------------------------------------
NOW_FILE = CACHE / "now-playing.json"


def write_now_playing(state):
    try:
        write_json(NOW_FILE, dict(state, updated=time.time()))
    except OSError:
        pass


def read_now_playing():
    s = read_json(NOW_FILE, {})
    if not s or time.time() - s.get("updated", 0) > 8:
        return {}
    return s


# ---------------------------------------------------------------- weather (Open-Meteo, no key)
WEATHER = {0: ("Clear", "☀️"), 1: ("Mostly clear", "🌤️"), 2: ("Partly cloudy", "⛅"), 3: ("Overcast", "☁️"),
           45: ("Fog", "🌫️"), 48: ("Fog", "🌫️"), 51: ("Drizzle", "🌦️"), 53: ("Drizzle", "🌦️"),
           55: ("Drizzle", "🌦️"), 61: ("Rain", "🌧️"), 63: ("Rain", "🌧️"), 65: ("Heavy rain", "🌧️"),
           71: ("Snow", "🌨️"), 73: ("Snow", "🌨️"), 75: ("Heavy snow", "❄️"), 80: ("Showers", "🌦️"),
           81: ("Showers", "🌧️"), 82: ("Heavy showers", "🌧️"), 95: ("Thunderstorm", "⛈️"),
           96: ("Thunderstorm", "⛈️"), 99: ("Thunderstorm", "⛈️")}


def weather_text(code):
    return WEATHER.get(int(code), ("Unknown", "🌡️"))


def _get_json(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": "AuroraOS/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def geocode(query):
    q = urllib.parse.quote(query.strip())
    data = _get_json(f"https://geocoding-api.open-meteo.com/v1/search?name={q}&count=6&language=en&format=json")
    return [{"name": r.get("name", ""), "region": r.get("admin1", ""), "country": r.get("country", ""),
             "lat": r["latitude"], "lon": r["longitude"]} for r in data.get("results", [])]


def fetch_weather(lat, lon, units="metric"):
    unit = "&temperature_unit=fahrenheit&wind_speed_unit=mph" if units == "imperial" else ""
    url = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
           "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m"
           "&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=5%s"
           % (lat, lon, unit))
    d = _get_json(url)
    cur, daily = d["current"], d["daily"]
    days = [{"date": daily["time"][i], "code": daily["weather_code"][i],
             "max": daily["temperature_2m_max"][i], "min": daily["temperature_2m_min"][i]}
            for i in range(len(daily["time"]))]
    return {"temp": cur["temperature_2m"], "feels": cur["apparent_temperature"], "code": cur["weather_code"],
            "wind": cur["wind_speed_10m"], "days": days}


# ---------------------------------------------------------------- system stats
class Stats:
    def __init__(self):
        self._prev = self._cpu_times()

    @staticmethod
    def _cpu_times():
        try:
            with open("/proc/stat") as fh:
                parts = fh.readline().split()[1:]
            vals = [int(x) for x in parts]
            idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
            return sum(vals), idle
        except (OSError, ValueError, IndexError):
            return 0, 0

    def cpu_percent(self):
        total, idle = self._cpu_times()
        pt, pi = self._prev
        self._prev = (total, idle)
        dt = total - pt
        return 0.0 if dt <= 0 else max(0.0, min(100.0, 100.0 * (1 - (idle - pi) / dt)))

    @staticmethod
    def memory():
        info = {}
        try:
            with open("/proc/meminfo") as fh:
                for line in fh:
                    k, _, v = line.partition(":")
                    info[k] = int(v.split()[0]) * 1024
        except (OSError, ValueError, IndexError):
            return 0, 0
        total = info.get("MemTotal", 0)
        return total - info.get("MemAvailable", 0), total

    @staticmethod
    def temperature():
        try:
            with open("/sys/class/thermal/thermal_zone0/temp") as fh:
                return int(fh.read().strip()) / 1000.0
        except (OSError, ValueError):
            return None

    @staticmethod
    def disk(path="/"):
        import shutil
        u = shutil.disk_usage(path)
        return u.used, u.total

    @staticmethod
    def uptime():
        try:
            with open("/proc/uptime") as fh:
                return float(fh.read().split()[0])
        except (OSError, ValueError, IndexError):
            return 0.0


def human_bytes(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024


def human_uptime(sec):
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return (f"{d}d " if d else "") + f"{h}h {m}m"


# ---------------------------------------------------------------- calendar events
EVENTS_FILE = CONFIG / "events.json"


def load_events():
    return read_json(EVENTS_FILE, [])


def save_events(events):
    write_json(EVENTS_FILE, events)


def events_for(events, d):
    key = d.isoformat()
    return sorted((e for e in events if e.get("date") == key), key=lambda e: e.get("time", ""))


def days_with_events(events, year, month):
    out = set()
    for e in events:
        try:
            ed = date.fromisoformat(e["date"])
        except (KeyError, ValueError):
            continue
        if ed.year == year and ed.month == month:
            out.add(ed.day)
    return out


# ---------------------------------------------------------------- recent files
def recent_files(limit=8):
    f = HOME / ".local/share/recently-used.xbel"
    out = []
    try:
        root = ET.parse(f).getroot()
        for b in root.iter("bookmark"):
            href = b.get("href", "")
            if not href.startswith("file://"):
                continue
            path = urllib.parse.unquote(href[7:])
            if os.path.exists(path):
                out.append((b.get("modified", ""), path))
    except (OSError, ET.ParseError):
        return []
    out.sort(reverse=True)
    seen, res = set(), []
    for _, p in out:
        if p not in seen:
            seen.add(p)
            res.append(p)
        if len(res) >= limit:
            break
    return res
