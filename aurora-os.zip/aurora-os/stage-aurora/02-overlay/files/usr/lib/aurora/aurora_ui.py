"""Aurora UI: one shared look (colours, shapes, widgets) for every Aurora app.

stylesheet() and the colour helpers need no Qt, so they can be tested anywhere.
The drawing helpers import PyQt6 lazily.
"""
import colorsys

PALETTES = {
    "dark": {"bg": "#101116", "surface": "#171922", "card": "rgba(255,255,255,0.050)",
             "card_hover": "rgba(255,255,255,0.085)", "border": "rgba(255,255,255,0.085)",
             "text": "#eceef5", "muted": "#9a9fb2", "field": "rgba(255,255,255,0.07)",
             "groove": "rgba(255,255,255,0.14)", "scroll": "rgba(255,255,255,0.20)"},
    "light": {"bg": "#f3f4f8", "surface": "#ffffff", "card": "rgba(0,0,0,0.045)",
              "card_hover": "rgba(0,0,0,0.075)", "border": "rgba(0,0,0,0.085)",
              "text": "#16171c", "muted": "#6b7080", "field": "rgba(0,0,0,0.06)",
              "groove": "rgba(0,0,0,0.14)", "scroll": "rgba(0,0,0,0.22)"},
}


def hex_to_rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def rgba(h, a):
    r, g, b = hex_to_rgb(h)
    return f"rgba({r},{g},{b},{a})"


def readable_on(h):
    """Black or white text, whichever is readable on the colour h."""
    r, g, b = hex_to_rgb(h)
    return "#0b0c10" if (0.299 * r + 0.587 * g + 0.114 * b) > 150 else "#ffffff"


def tint(h, lightness=None, saturation=None):
    r, g, b = [x / 255 for x in hex_to_rgb(h)]
    hh, ll, ss = colorsys.rgb_to_hls(r, g, b)
    ll = ll if lightness is None else lightness
    ss = ss if saturation is None else saturation
    r, g, b = colorsys.hls_to_rgb(hh, ll, ss)
    return "#%02x%02x%02x" % (round(r * 255), round(g * 255), round(b * 255))


def stylesheet(theme):
    p = PALETTES[theme.get("mode", "dark")]
    acc = theme.get("accent", "#8296ff")
    rad = int(theme.get("radius", 18))
    on_acc = readable_on(acc)
    return f"""
* {{ font-family: "Inter", "Noto Sans", sans-serif; font-size: 13px; color: {p['text']}; }}
QWidget {{ background: transparent; }}
QMainWindow, QDialog, QMessageBox, QInputDialog {{ background: {p['bg']}; }}
QToolTip {{ background: {p['surface']}; color: {p['text']}; border: 1px solid {p['border']}; border-radius: 8px; padding: 6px 8px; }}

QFrame#Card {{ background: {p['card']}; border: 1px solid {p['border']}; border-radius: {rad}px; }}
QFrame#Card:hover {{ background: {p['card']}; }}
QFrame#Panel {{ background: {p['surface']}; border: none; border-radius: {rad}px; }}
QFrame#Sidebar {{ background: {p['surface']}; border: none; }}

QLabel {{ background: transparent; }}
QLabel#Title {{ font-size: 22px; font-weight: 600; }}
QLabel#Big {{ font-size: 56px; font-weight: 300; }}
QLabel#Heading {{ font-size: 15px; font-weight: 600; }}
QLabel#Muted {{ color: {p['muted']}; }}
QLabel#Small {{ color: {p['muted']}; font-size: 11px; }}
QLabel#Accent {{ color: {acc}; font-weight: 600; }}

QPushButton {{ background: {p['field']}; border: none; border-radius: 12px; padding: 8px 16px; }}
QPushButton:hover {{ background: {p['card_hover']}; }}
QPushButton:pressed {{ background: {rgba(acc, 0.25)}; }}
QPushButton:disabled {{ color: {p['muted']}; }}
QPushButton#Accent {{ background: {acc}; color: {on_acc}; font-weight: 600; }}
QPushButton#Accent:hover {{ background: {tint(acc, 0.66)}; }}
QPushButton#Flat {{ background: transparent; }}
QPushButton#Flat:hover {{ background: {p['field']}; }}

QToolButton {{ background: transparent; border: none; border-radius: 14px; padding: 6px; }}
QToolButton:hover {{ background: {p['field']}; }}
QToolButton:checked {{ background: {rgba(acc, 0.22)}; }}
QToolButton#Play {{ background: {acc}; border-radius: 26px; padding: 12px; }}
QToolButton#Play:hover {{ background: {tint(acc, 0.66)}; }}

QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox {{
    background: {p['field']}; border: 1px solid transparent; border-radius: 12px; padding: 8px 12px; selection-background-color: {acc}; selection-color: {on_acc}; }}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border: 1px solid {acc}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 10px; selection-background-color: {rgba(acc, 0.28)}; padding: 4px; }}
QCheckBox {{ spacing: 10px; }}
QCheckBox::indicator {{ width: 38px; height: 22px; border-radius: 11px; background: {p['groove']}; }}
QCheckBox::indicator:checked {{ background: {acc}; }}

QSlider::groove:horizontal {{ height: 4px; background: {p['groove']}; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {acc}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: #ffffff; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }}
QSlider::groove:vertical {{ width: 4px; background: {p['groove']}; border-radius: 2px; }}
QSlider::add-page:vertical {{ background: {acc}; border-radius: 2px; }}
QSlider::handle:vertical {{ background: #ffffff; height: 14px; width: 14px; margin: 0 -5px; border-radius: 7px; }}

QProgressBar {{ background: {p['groove']}; border: none; border-radius: 3px; max-height: 6px; min-height: 6px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ background: {acc}; border-radius: 3px; }}

QScrollBar:vertical {{ width: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p['scroll']}; border-radius: 4px; min-height: 36px; }}
QScrollBar:horizontal {{ height: 10px; background: transparent; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {p['scroll']}; border-radius: 4px; min-width: 36px; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ background: none; height: 0; width: 0; }}

QListWidget, QListView, QTableView, QTreeView, QTreeWidget {{ background: transparent; border: none; outline: 0; }}
QListWidget::item {{ padding: 9px 12px; border-radius: 10px; margin: 1px 4px; }}
QListWidget::item:hover {{ background: {p['field']}; }}
QListWidget::item:selected {{ background: {rgba(acc, 0.24)}; color: {p['text']}; }}
QTableView {{ gridline-color: transparent; selection-background-color: transparent; }}
QTableView::item {{ padding: 0 10px; border: none; }}
QTableView::item:hover {{ background: {p['field']}; }}
QTableView::item:selected {{ background: {rgba(acc, 0.24)}; color: {p['text']}; }}
QHeaderView {{ background: transparent; }}
QHeaderView::section {{ background: transparent; color: {p['muted']}; border: none; padding: 8px 10px; font-size: 11px; }}

QMenu {{ background: {p['surface']}; border: 1px solid {p['border']}; border-radius: 12px; padding: 6px; }}
QMenu::item {{ padding: 8px 20px; border-radius: 8px; }}
QMenu::item:selected {{ background: {rgba(acc, 0.28)}; }}
QMenu::separator {{ height: 1px; background: {p['border']}; margin: 6px 10px; }}

QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; color: {p['muted']}; padding: 9px 16px; margin: 2px; border-radius: 12px; }}
QTabBar::tab:selected {{ background: {rgba(acc, 0.22)}; color: {p['text']}; }}
QTabBar::tab:hover {{ background: {p['field']}; }}
QGroupBox {{ border: 1px solid {p['border']}; border-radius: {rad}px; margin-top: 16px; padding: 16px 12px 12px 12px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 14px; color: {p['muted']}; }}
"""


# ---- Qt helpers (PyQt6 imported on demand) --------------------------------------------------
def rounded_pixmap(pix, size, radius):
    """Square, cropped, rounded copy of pix."""
    from PyQt6.QtCore import Qt, QRectF
    from PyQt6.QtGui import QPainter, QPainterPath, QPixmap
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    if pix is None or pix.isNull():
        return out
    scaled = pix.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                        Qt.TransformationMode.SmoothTransformation)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    path = QPainterPath()
    path.addRoundedRect(QRectF(0, 0, size, size), radius, radius)
    p.setClipPath(path)
    p.drawPixmap((size - scaled.width()) // 2, (size - scaled.height()) // 2, scaled)
    p.end()
    return out


def placeholder_cover(size, accent="#8296ff", radius=18):
    """Soft gradient tile with a music note, used when a track has no artwork."""
    from PyQt6.QtCore import Qt, QRectF
    from PyQt6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPixmap
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    g.setColorAt(0, QColor(tint(accent, 0.45, 0.55)))
    g.setColorAt(1, QColor(tint(accent, 0.22, 0.60)))
    path = QPainterPath()
    path.addRoundedRect(QRectF(0, 0, size, size), radius, radius)
    p.fillPath(path, g)
    f = QFont()
    f.setPixelSize(int(size * 0.5))
    p.setFont(f)
    p.setPen(QColor(255, 255, 255, 210))
    p.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, "♪")
    p.end()
    return pm


def average_color(pix):
    """Average colour of a pixmap as '#rrggbb' (used to tint Now Playing)."""
    from PyQt6.QtCore import Qt
    if pix is None or pix.isNull():
        return None
    img = pix.toImage().scaled(1, 1, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
    c = img.pixelColor(0, 0)
    return "#%02x%02x%02x" % (c.red(), c.green(), c.blue())


def glyph(name, size=22, color="#eceef5", filled=False):
    """Crisp vector icons drawn in code, so every control matches the theme colour."""
    from PyQt6.QtCore import Qt, QPointF, QRectF
    from PyQt6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap
    s = size * 2
    pm = QPixmap(s, s)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(color)
    pen = QPen(c)
    pen.setWidthF(s * 0.085)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)

    def P(x, y):
        return QPointF(x * s, y * s)

    def poly(points):
        path = QPainterPath()
        path.moveTo(P(*points[0]))
        for pt in points[1:]:
            path.lineTo(P(*pt))
        path.closeSubpath()
        return path

    def fill(path):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(c)
        p.drawPath(path)

    def stroke(path):
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)

    if name == "play":
        fill(poly([(0.32, 0.20), (0.80, 0.50), (0.32, 0.80)]))
    elif name == "pause":
        for x in (0.28, 0.56):
            path = QPainterPath()
            path.addRoundedRect(QRectF(x * s, 0.2 * s, 0.16 * s, 0.6 * s), 0.05 * s, 0.05 * s)
            fill(path)
    elif name in ("next", "prev"):
        pts = [(0.22, 0.22), (0.66, 0.50), (0.22, 0.78)]
        if name == "prev":
            pts = [(1 - x, y) for x, y in pts]
        fill(poly(pts))
        bar = QPainterPath()
        bx = 0.70 if name == "next" else 0.22
        bar.addRoundedRect(QRectF(bx * s, 0.22 * s, 0.09 * s, 0.56 * s), 0.03 * s, 0.03 * s)
        fill(bar)
    elif name == "shuffle":
        path = QPainterPath()
        path.moveTo(P(0.14, 0.70)); path.cubicTo(P(0.45, 0.70), P(0.5, 0.30), P(0.76, 0.30))
        path.moveTo(P(0.14, 0.30)); path.cubicTo(P(0.45, 0.30), P(0.5, 0.70), P(0.76, 0.70))
        stroke(path)
        fill(poly([(0.74, 0.18), (0.92, 0.30), (0.74, 0.42)]))
        fill(poly([(0.74, 0.58), (0.92, 0.70), (0.74, 0.82)]))
    elif name in ("repeat", "repeat1"):
        path = QPainterPath()
        path.addRoundedRect(QRectF(0.14 * s, 0.27 * s, 0.72 * s, 0.46 * s), 0.14 * s, 0.14 * s)
        stroke(path)
        fill(poly([(0.60, 0.12), (0.78, 0.27), (0.60, 0.42)]))
        if name == "repeat1":
            p.setPen(c)
            f = p.font()
            f.setPixelSize(int(s * 0.30))
            f.setBold(True)
            p.setFont(f)
            p.drawText(QRectF(0.35 * s, 0.33 * s, 0.30 * s, 0.34 * s), Qt.AlignmentFlag.AlignCenter, "1")
    elif name == "heart":
        path = QPainterPath()
        path.moveTo(P(0.5, 0.84))
        path.cubicTo(P(0.12, 0.58), P(0.14, 0.22), P(0.34, 0.22))
        path.cubicTo(P(0.44, 0.22), P(0.5, 0.30), P(0.5, 0.36))
        path.cubicTo(P(0.5, 0.30), P(P(0.56, 0.22).x() / s, 0.22), P(0.66, 0.22))
        path.cubicTo(P(0.86, 0.22), P(0.88, 0.58), P(0.5, 0.84))
        (fill if filled else stroke)(path)
    elif name == "volume":
        fill(poly([(0.16, 0.40), (0.30, 0.40), (0.50, 0.24), (0.50, 0.76), (0.30, 0.60), (0.16, 0.60)]))
        for r in (0.14, 0.26):
            path = QPainterPath()
            path.arcMoveTo(QRectF((0.5 - r) * s, (0.5 - r) * s, 2 * r * s, 2 * r * s), 40)
            path.arcTo(QRectF((0.5 - r) * s, (0.5 - r) * s, 2 * r * s, 2 * r * s), 40, -80)
            p.translate(0.22 * s, 0)
            stroke(path)
            p.translate(-0.22 * s, 0)
    elif name == "plus":
        path = QPainterPath()
        path.moveTo(P(0.5, 0.2)); path.lineTo(P(0.5, 0.8))
        path.moveTo(P(0.2, 0.5)); path.lineTo(P(0.8, 0.5))
        stroke(path)
    elif name == "search":
        path = QPainterPath()
        path.addEllipse(QRectF(0.18 * s, 0.18 * s, 0.46 * s, 0.46 * s))
        path.moveTo(P(0.56, 0.56)); path.lineTo(P(0.82, 0.82))
        stroke(path)
    elif name == "settings":
        path = QPainterPath()
        for y, kx in ((0.28, 0.32), (0.50, 0.66), (0.72, 0.44)):
            path.moveTo(P(0.18, y)); path.lineTo(P(0.82, y))
        stroke(path)
        p.setBrush(c)
        p.setPen(Qt.PenStyle.NoPen)
        for y, kx in ((0.28, 0.32), (0.50, 0.66), (0.72, 0.44)):
            p.drawEllipse(P(kx, y), 0.07 * s, 0.07 * s)
    elif name == "close":
        path = QPainterPath()
        path.moveTo(P(0.28, 0.28)); path.lineTo(P(0.72, 0.72))
        path.moveTo(P(0.72, 0.28)); path.lineTo(P(0.28, 0.72))
        stroke(path)
    elif name == "chevron_left" or name == "chevron_right":
        path = QPainterPath()
        a, b = (0.62, 0.38) if name == "chevron_left" else (0.38, 0.62)
        path.moveTo(P(a, 0.25)); path.lineTo(P(b, 0.5)); path.lineTo(P(a, 0.75))
        stroke(path)
    elif name == "folder":
        path = QPainterPath()
        path.moveTo(P(0.14, 0.30)); path.lineTo(P(0.40, 0.30)); path.lineTo(P(0.48, 0.38))
        path.lineTo(P(0.86, 0.38)); path.lineTo(P(0.86, 0.76)); path.lineTo(P(0.14, 0.76)); path.closeSubpath()
        stroke(path)
    p.end()
    pm.setDevicePixelRatio(2)
    return QIcon(pm)


class FlowCard:
    """Factory for a Card frame with a vertical layout (kept simple on purpose)."""

    @staticmethod
    def make(parent=None, margins=(20, 18, 20, 18), spacing=10):
        from PyQt6.QtWidgets import QFrame, QVBoxLayout
        card = QFrame(parent)
        card.setObjectName("Card")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(*margins)
        lay.setSpacing(spacing)
        return card, lay
